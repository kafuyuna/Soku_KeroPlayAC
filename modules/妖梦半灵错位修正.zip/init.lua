-- 修复妖梦半灵错位 bug
-- Fix Youmu's myon corrupt bug

-- 鱼蛙：那个半灵错位的bug，基本能搞清楚原理了，主要就是center偏移导致的。
-- 开幽冥后半灵变为角色贴图，对于飞行和受击回转这种旋转类的动作，center会被设置为旋转中心相对于物体锚点的偏移值，这样贴图的缩放和旋转就会按照center来进行
-- 问题是分身重置回半灵状态时没有重置center和旋转角，结果就错位了
-- 我懒得查反编译的代码了，你如果要用lua修可以试着在重置的时机这样搞：
-- obj.renderInfo.zRotation = 0
-- memory.writefloat(obj.ptr+0x108, 0)
-- memory.writefloat(obj.ptr+0x10C, 0)

CloseDesyncAlert = true
HideBugFx = true

local tramp = nil
if not HideBugFx then
    tramp = memory.readbytes(0x57fa82, 12)
    memory.writebytes(0x57fa82, "\x8B\x96\x5C\x03\x00\x00" .. "\xD9\x42\x04" .. "\x90\x90\x90") --移除固定速，改为由obj.customData[2]控制

    memory.hookcall(0x58654c, memory.createcallback(0, function(state)
        return battle.random(3) --fix unlimited rand range
    end))
end
local function hide_static(obj, target)
    target = target or 0x00FFFFFF
    local oc = memory.readint(obj.ptr + 0x150)
    if oc == 0 then return false end
    oc = memory.readint(oc + 0x18)
    if oc == 0 then return false end
    memory.writeint(oc + 0x4, target)
    return true, oc
end

local function youmuObjectUpdate(obj, actId, data)
    if actId == 899 then
        -- 修复幽冥结束后半灵错位的bug
        obj.renderInfo.zRotation = 0
        memory.writefloat(obj.ptr + 0x108, 0)
        memory.writefloat(obj.ptr + 0x10C, 0)
        return
    end
    if actId == 855 and obj.sequenceId == 2 then
        -- 修复幽冥横线竖线特效的bug
        if HideBugFx then
            obj.lifetime = 0
            -- obj.renderInfo.scale.x = 0
            -- obj.renderInfo.scale.y = 0
            --[[ if (not data["Hided"]) then
                hide_static(obj); obj:setPose(1);
                hide_static(obj); obj:setPose(0);
                data["Hided"] = true
            end ]]
            return
        end

        if obj.currentFrame == 0 then
            obj.customData[2] = 10 --更改移速
            -- obj.gpFloat[1] = obj.position.x
            -- obj.gpFloat[2] = obj.position.y
            -- obj.gpShort[1] = math.floor(obj.customData[1])%2==0 and 1 or -1 -- 旋转方向
            -- obj.gpShort[2] = math.random(3)
        end
        --[[ local orgPos = soku.Vector2f(obj.gpFloat[1], obj.gpFloat[2])
        obj.customData[1] = obj.customData[1] + obj.gpShort[1]*obj.gpShort[2]
        obj.renderInfo.zRotation = obj.customData[1]
        local radi = (obj.position - orgPos):length() + obj.customData[2]
        obj.position = soku.Vector2f(radi, 0):rotate(-obj.direction*math.rad(obj.renderInfo.zRotation+ (obj.direction>0 and 0 or 180)), soku.Vector2f(0,0)) + orgPos ]]

        return
    end
    if actId == 820 and obj.sequenceId <= 2 then
        -- 修复磷气斩的特效贴图没有调转方向的bug
        if obj.direction < 0 and obj.renderInfo.xRotation > 0 then
            obj.renderInfo.xRotation = -obj.renderInfo.xRotation
        end
        return
    end
end

--[[ function YoumuObjectInitAction(obj, actId, data)
    if actId == 855 and obj.sequenceId == 2 then
        -- 修复幽冥横线竖线特效的bug
        if HideBugFx then
            print("aaa")
            obj:setActionSequence(998, 0)
            -- obj.lifetime = 0
            -- obj.renderInfo.scale.x = 0
            -- obj.renderInfo.scale.y = 0
            -- if (not data["Hided"]) then
            --     hide_static(obj); obj:setPose(1);
            --     hide_static(obj); obj:setPose(0);
            --     data["Hided"] = true
            -- end
            return
        end
    end
end ]]

battle.replaceObjects(soku.Character.Youmu, youmuObjectUpdate, nil, function()
    -- math.randomseed(battle.manager.randomSeed)
end)

local function GetPlayer(a) -- 输入参数为数字 1 2
    return (a == 1) and battle.manager.player1 or battle.manager.player2
end
memory.hooktramp(0x488789, 7, memory.createcallback(0, function(cpu)
    for a = 1, 2 do
        local p = GetPlayer(a)
        if p.actionId >= 197 and p.actionId <= 199 and p.sequenceId <= 1 and p.currentFrame <= 18 then
            memory.writeshort(p.ptr + 0x7F7, 1) -- CF_DAMAGE_LIMITED 0x7F7 // bool，flag为0且Limit大于等于100就生成一个蓝圈，然后flag为1
        end
    end
end))


function AtExit()
    if tramp then
        memory.writebytes(0x57fa82, tramp)
    end
end
