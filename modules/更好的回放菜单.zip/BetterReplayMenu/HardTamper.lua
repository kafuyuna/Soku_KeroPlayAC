local HardTamper ={}

local posx = 0x87153c -- `180.0f`
local ADDR_WIDTH = 0x42c6c9 + 6
local ADDR_POSX = 0x44b04a + 2
local ADDR_WIDTH_BAR = 0x44afb3 + 2
local ADDR_POSX_BAR = 0x44afe6 + 2

HardTamper.tampered = false
local nop = string.char(0x90)
HardTamper.list = {
---[[wider list
	--chars; mov [esi+0xa8], 36 -> 54
	[ADDR_WIDTH]=54,
	
	--fld 304.0f -> 180.0f
	[ADDR_POSX]=posx,
	[ADDR_POSX_BAR]=posx,
	--double cursor width
	[ADDR_WIDTH_BAR]=0x857f88,
--]]

--[[column show path only
	[0x44b110]="\x90\x50",
	-- %s%s ->%s
	[0x44b117]=0x861b54,
	-- re-balance stack 16->12
	[0x44b124]=string.pack("=b", 12),
	-- cut path str head "replay"
	[0x44b137]="\x2E",
--]]
}

local function applyList()
	local list = HardTamper.list
	for addr, val in pairs(list) do
		local ogv = nil
		if(type(val)=="number") then
			ogv = memory.readint(addr)
			memory.writeint(addr, val)
		elseif(type(val)=="string") then
			ogv = memory.readbytes(addr, #val)
			memory.writebytes(addr, val)
		end
		list[addr] = ogv
	end
end

function HardTamper.tamper()
	if(HardTamper.tampered) then return; end
	applyList()
	HardTamper.tampered = true
end

function HardTamper.restore()
	if(not HardTamper.tampered) then return; end
	applyList()
	HardTamper.tampered = false
end

return HardTamper