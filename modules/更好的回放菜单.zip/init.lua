local Hf = dofile("BetterReplayMenu/HardTamper.lua")
Hf.tamper()
function AtExit()
	Hf.restore()
end

---[[pos indicator
local ADDR_MENU_LIST = 0x89a884
local ADDR_VTBL_REPLAY_MENU = 0x8596f4
local function getCurrentMenu()
	local ph, sz= memory.readint(ADDR_MENU_LIST+0x4), memory.readint(ADDR_MENU_LIST+0x8)
	--print(ph, sz)
	if(sz<=0) then return end
	local pb = memory.readint(ph+0x4)
	if(pb~=0) then
		return memory.readint(pb+0x8)
	end
end
local ROW_IN_SCREEN = 12
local function getCursorPos(menuPtr)
	local row = memory.readshort(menuPtr+0x3D4)
	local cpos = memory.readint(menuPtr+0x3E0)
	local spos = memory.readint(menuPtr+0x3E4)
	local fla = memory.readint(menuPtr+0x540)
	return spos, cpos, row, fla
end
local function setCursorPos(menuPtr, spos, cpos)
	memory.writeint(menuPtr+0x3E4, spos)
	memory.writeint(menuPtr+0x3E0, cpos)
end

local slider_height = 236
local slider_posY = nil
soku.SubscribeSceneChange(
	function()
		return function(scene)
			local dat = scene.data
			if(gui.isMenuOpen()) then
				local pm = getCurrentMenu()
				if(memory.readint(pm)==ADDR_VTBL_REPLAY_MENU) then
					--print( string.format("into the replay menu: 0x%x", pm))
					local pd = pm+0x380
					dat[pm]= dat[pm] or {}
					
					dat[pm]["design"] = dat[pm]["design"] or gui.Design.fromPtr(pd)
					local design = dat[pm]["design"]
					
					local slider = design:getItemById(800)
										
					if(not dat[pm]["vs"]) then
						dat[pm]["vs"] = dat[pm]["vs"] or slider:getValueControl()
						slider.isActive = true
					end
					if(not dat[pm]["v1"]) then
						local num1 = design:getItemById(900)
						dat[pm]["v1"] = dat[pm]["v1"] or num1:getValueControl()
						num1.isActive = true
						--num1:setColor(0xCFFFFFFF)
					end
					if(not dat[pm]["v2"]) then
						local num2 = design:getItemById(901)
						dat[pm]["v2"] = dat[pm]["v2"] or num2:getValueControl()
						num2.isActive = true
						--num2:setColor(0xCFFFFFFF)
					end
					design:getItemById(700).isActive=true
					local vs = dat[pm]["vs"]
					local v1 = dat[pm]["v1"]
					local v2 = dat[pm]["v2"]
					
					local s, c, r, f=getCursorPos(pm)
					--locate slider
					slider_posY = slider_posY or slider.y
					slider.y = slider_posY-math.max(0, 1-(s+ROW_IN_SCREEN)/r)*slider_height
					vs.gauge = math.floor(100*math.min(1, math.min(r-s, ROW_IN_SCREEN)/r))
					
					--show number
					v1.number = c+1
					v2.number = r
					
					--show ellipsis
					design:getItemById(1000).isActive= s+ROW_IN_SCREEN<r

					--fix entrance bug
					if(dat[pm]["folder"] and dat[pm]["folder"]<f) then
						setCursorPos(pm, 0, 0)
					end
					dat[pm]["folder"] = f
				end
			else
				scene.data={}
			end
			
		end
	end
	
)--]]