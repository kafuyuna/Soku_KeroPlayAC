local path = "dataBetterDebug/"
local resource = path .. "debugs.xml"
local HotKey = 0x40 --F6
-- local HotKey= 0x42	--F8

local function GetPlayer(i) -- �������Ϊ���� 1 2
	return (i == 1) and battle.manager.player1 or battle.manager.player2
end
local p
local Flag_ptr_Control = {}

local db = {
	display = false,
	element_texts = {
		--[800]="֡"
	},
	element_tree = { --ע��������������
		--10,--P1 hp
		--15,--P2 hp
		[1] = {
			[20] = { 21, 22 }, --pos
			[30] = {
				31,
				32,                                   --speed
				[40] = { 41 },                        --gravity
			},
			[50] = { 51, 52, 53, 54, 55, 56, 57, 58 }, --pattern
			[70] = { 71, 72, 73, 74 },              --stat
		},
		[2] = {
			[25] = { 26, 27 },
			[35] = {
				36,
				37,
				[45] = { 46 },
			},
			[60] = { 61, 62, 63, 64, 65, 66, 67, 68 },
			[75] = { 76, 77, 78, 79 },
		},
		--80,
		[81] = { 82 },
		--85,
		[86] = { 87 },
		--90,95,
		[1000] = { 1001, 1002, 1003 },
	},

}
local tf = gui.Font(); tf:setFontName("DengXian"); tf.shadow = 1; tf.height = 16
--[[
local function calcuExtraXSpeed(player)
	local speed = 0
	if math.abs(player.opponent.position.x-640)>=600 and player.opponent.hitStop==0 then
		speed = player.opponent.speed.x
	end
	return speed*0.75 + memory.readfloat(player.ptr+0x744)
end--]]

function db.constructor(scene)
	local new = {
		scene = scene,
		inited = false,
		keydown = false, --��鰴�¶��ǰ�ס��ԭ�淽���ǣ�
		mutables = {},
	}
	function new:checker()
		local lastk = self.keydown
		self.keydown = memory.readbytes(0x8a01b8 + HotKey, 1) == "\x80" --soku.checkFKey(HotKey)
		if (self.keydown and lastk == false) then
			return true
		end
		return false
	end

	function new:updater()
		if self.inited and not db.display then return end
		if not self.inited then
			self.scene.renderer.isActive = db.display --��updater����active�������ʾǰ�ض���ʼ��
			self.inited = true
		end

		local timer1 = memory.readint(0x8985d8) --thanks hagb~~
		local timer2 = self.scene.data["counter"] or -1
		local buffer = self.scene.data["numberbuffer"]
		local p1, p2 = battle.manager.player1, battle.manager.player2
		local seq1, seq2 = memory.readint(p1.ptr + 0x15C), memory.readint(p2.ptr + 0x15C)

		-- �����Ƿ���Ӳֱ�͵����ܻ�Ӳֱ����
		local p1StunUntech = 0
		local p2StunUntech = 0
		local SpinAttackSeqID = { 0, 2, 14, 26 }
		local CrushAttackSeqID = { 0, 3, 44 }

		if p1.actionId == 50 or p1.actionId == 56  or p1.actionId == 62 then
			p1StunUntech = 10 - p1.currentFrame
		elseif p1.actionId == 51 or p1.actionId == 57  or p1.actionId == 63 then
			p1StunUntech = 17 - p1.currentFrame
		elseif p1.actionId == 52 or p1.actionId == 58  or p1.actionId == 64 then
			p1StunUntech = 24 - p1.currentFrame
		elseif p1.actionId == 150 or p1.actionId == 154 then
			p1StunUntech = 9 - p1.currentFrame
		elseif p1.actionId == 151 or p1.actionId == 155 then
			p1StunUntech = 15 - p1.currentFrame
		elseif p1.actionId == 152 or p1.actionId == 156 then
			p1StunUntech = 21 - p1.currentFrame
		elseif p1.actionId == 153 or p1.actionId == 157 then
			p1StunUntech = 27 - p1.currentFrame
		elseif p1.actionId == 159 or p1.actionId == 163 then
			p1StunUntech = 11 - p1.currentFrame
		elseif p1.actionId == 160 or p1.actionId == 164 then
			p1StunUntech = 19 - p1.currentFrame
		elseif p1.actionId == 161 or p1.actionId == 165 then
			p1StunUntech = 27 - p1.currentFrame
		elseif p1.actionId == 162 or p1.actionId == 166 then
			p1StunUntech = 31 - p1.currentFrame
		elseif p1.actionId == 143 then
			p1StunUntech = 49 - p1.currentFrame - CrushAttackSeqID[p1.sequenceId + 1]
		elseif p1.actionId == 158 then
			p1StunUntech = 19 - p1.currentFrame
		elseif p1.actionId == 53 or p1.actionId == 59 or p1.actionId == 65 then
			p1StunUntech = 34 - p1.currentFrame - SpinAttackSeqID[p1.sequenceId + 1]
		else
			p1StunUntech = p1.untech
		end

		--  ������P2�ķ���Ӳֱ�͵����ܻ�Ӳֱ����
		if p2.actionId == 50 or p2.actionId == 56  or p2.actionId == 62  then
			p2StunUntech = 10 - p2.currentFrame
		elseif p2.actionId == 51 or p2.actionId == 57   or p2.actionId == 63 then
			p2StunUntech = 17 - p2.currentFrame
		elseif p2.actionId == 52 or p2.actionId == 58  or p2.actionId == 64 then
			p2StunUntech = 24 - p2.currentFrame
		elseif p2.actionId == 150 or p2.actionId == 154 then
			p2StunUntech = 9 - p2.currentFrame
		elseif p2.actionId == 151 or p2.actionId == 155 then
			p2StunUntech = 15 - p2.currentFrame
		elseif p2.actionId == 152 or p2.actionId == 156 then
			p2StunUntech = 21 - p2.currentFrame
		elseif p2.actionId == 153 or p2.actionId == 157 then
			p2StunUntech = 27 - p2.currentFrame
		elseif p2.actionId == 159 or p2.actionId == 163 then
			p2StunUntech = 11 - p2.currentFrame
		elseif p2.actionId == 160 or p2.actionId == 164 then
			p2StunUntech = 19 - p2.currentFrame
		elseif p2.actionId == 161 or p2.actionId == 165 then
			p2StunUntech = 27 - p2.currentFrame
		elseif p2.actionId == 162 or p2.actionId == 166 then
			p2StunUntech = 31 - p2.currentFrame
		elseif p2.actionId == 143 then
			p2StunUntech = 49 - p2.currentFrame - CrushAttackSeqID[p2.sequenceId + 1]
		elseif p2.actionId == 158 then
			p2StunUntech = 19 - p2.currentFrame
		elseif p2.actionId == 53 or p2.actionId == 59 or p2.actionId == 65 then
			p2StunUntech = 34 - p2.currentFrame - SpinAttackSeqID[p2.sequenceId + 1]
		else
			p2StunUntech = p2.untech
		end


		local idval = {
			[10] = p1.hp, --[11]=memory.readshort(battle.manager.player1.ptr+0x498)-battle.manager.player1.hp,
			[15] = p2.hp, --[16]=memory.readshort(battle.manager.player2.ptr+0x498)-battle.manager.player2.hp,

			[21] = p1.position.x,
			[22] = p1.position.y,
			[26] = p2.position.x,
			[27] = p2.position.y,
			[31] = p1.speed.x,
			[32] = p1.speed.y,
			[41] = p1.gravity.y,
			[36] = p2.speed.x,
			[37] = p2.speed.y,
			[46] = p2.gravity.y,

			[51] = p1.actionId,
			[52] = p1.sequenceId,
			[53] = p1.poseId + memory.readshort(p1.ptr + 0x148) / 100,
			[54] = p1.poseFrame + memory.readshort(p1.ptr + 0x14C) / 1000,
			[55] = p1.currentFrame,
			[57] = memory.readshort(seq1 + 0x10),
			[58] = memory.readshort(seq1 + 0x12),
			[61] = p2.actionId,
			[62] = p2.sequenceId,
			[63] = p2.poseId + memory.readshort(p2.ptr + 0x148) / 100,
			[64] = p2.poseFrame + memory.readshort(p2.ptr + 0x14C) / 1000,
			[65] = p2.currentFrame,
			[67] = memory.readshort(seq2 + 0x10),
			[68] = memory.readshort(seq2 + 0x12),

			[71] = p1.collisionType,
			[72] = p1.collisionLimit,
			[73] = p1.hitStop, --[74]=p1.untech,
			[76] = p2.collisionType,
			[77] = p2.collisionLimit,
			[78] = p2.hitStop, --[79]=p2.untech,
			[74] = p1StunUntech,
			[79] = p2StunUntech,

			[80] = p1.currentSpirit / 200,
			[82] = memory.readshort(p1.ptr + 0x4a2),
			[85] = p2.currentSpirit / 200,
			[87] = memory.readshort(p2.ptr + 0x4a2),
			[90] = memory.readshort(p1.ptr + 0x5e4) / 500,
			[95] = memory.readshort(p2.ptr + 0x5e4) / 500,
			--��սʱ��
			[1001] = timer1 // 3600,
			[1002] = (timer1 % 3600) / 60,
			[1003] = timer1 % 60,

		}
		--��ȡ����Ԫ�ؿ���
		for id, val in pairs(idval) do
			if (not buffer[id]) then buffer[id] = self.scene.renderer.design:getItemById(id):getValueControl() end
			buffer[id].number = val
		end
		--others
		return true
	end

	function new:switcher()
		self.scene.renderer.isActive = not self.scene.renderer.isActive
		db.display = self.scene.renderer.isActive
	end

	function new:disable()
		--db.display = false
		self.scene.renderer.isActive = false
	end

	scene.renderer.design:loadResource(resource)
	scene.data["numberbuffer"] = {}
	---[[Ԫ�ذ�����λ
	local function traverse(t, x, y)
		x = x or 0; y = y or 0
		for id, ele in pairs(t) do
			if type(ele) == "table" then
				local cur = scene.renderer.design:getItemById(id)
				cur.x = cur.x + x; cur.y = cur.y + y
				traverse(ele, cur.x, cur.y)
			elseif type(ele) == "number" then
				local cur = scene.renderer.design:getItemById(ele)
				cur.x = cur.x + x; cur.y = cur.y + y
			end
		end
	end
	traverse(db.element_tree)


	--]]


	--����Ԫ��ȫ��������������
	for i = 1, scene.renderer.design:getItemCount() do
		scene.renderer.design:getItem(i).isActive = true
	end
	--�������
	new:disable() --����Ԫ�س�ʼ��ǰ��������ʾ���������
	return new
end

return setmetatable(db, {
	__call = function(t, scene)
		return t.constructor(scene)
	end,
})
