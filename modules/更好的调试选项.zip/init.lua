local path = "dataBetterDebug/"
local Db = dofile(path.."Debugs.lua")

soku.SubscribeSceneChange(
	function(newsId, scene)
		if(newsId~=soku.Scene.Battle) then return end
		
		scene.data["counter"]=0
		scene.data["debugs"]=Db(scene)
		return function(s)
			local dat = s.data
			local counter = dat["counter"]
			local debugs = dat["debugs"]
			
			local state = battle.manager.matchState
			local p1, p2 = battle.manager.player1, battle.manager.player2
			local score1,score2 = memory.readbytes(p1.ptr+0x573,1), memory.readbytes(p2.ptr+0x573,1)
			score1, score2 = string.unpack("b", score1), string.unpack("b", score2)
			if state==1 then
				dat["P1_unhurt"]=1
				dat["P2_unhurt"]=1
			elseif state==2 then
				if p1.hp < p1.maxHp then dat["P1_unhurt"]=0 end
				if p2.hp < p2.maxHp then dat["P2_unhurt"]=0 end
			elseif(state==6 and battle.manager.frameCount==0) then
				debugs:disable()
			end
			
			if debugs:checker() then
				debugs:switcher()
			end
			if debugs:updater() then
				if dat["P1_unhurt"] and dat["P2_unhurt"] then
					local colors = {[0]=0xFFffffff, [1]=0xFF4fff85}
					s.renderer.design:getItemById(10):setColor(colors[dat["P1_unhurt"]])
					s.renderer.design:getItemById(15):setColor(colors[dat["P2_unhurt"]])
				end
				--[[local gray = {[1]=0xFFffffff, [0]=0xBFbbbbbb}
				s.renderer.design:getItemById(50):setColor(gray[string.unpack("b", memory.readbytes(p1.ptr+0x135, 1))])
				s.renderer.design:getItemById(60):setColor(gray[string.unpack("b", memory.readbytes(p2.ptr+0x135, 1))])
				--]]
				local seq1, seq2 = memory.readint(p1.ptr + 0x15C), memory.readint(p2.ptr + 0x15C)
				s.renderer.design:getItemById(56).isActive = memory.readbytes(seq1+0x14, 1)=="\x01"
				s.renderer.design:getItemById(66).isActive = memory.readbytes(seq2+0x14, 1)=="\x01"
			end
			
			dat["counter"] = counter + 1
			return -1
		end
		
	end
)